/*
3442. Maximum Difference Between Even and Odd Frequency I

You are given a string s consisting of lowercase English letters.
Your task is to find the maximum difference diff = a1 - a2 between the frequency of characters a1 and a2 in the string such that:
a1 has an odd frequency in the string.
a2 has an even frequency in the string.
Return this maximum difference.

Example 1:
Input: s = "aaaaabbc"
Output: 3
Explanation:
The character 'a' has an odd frequency of 5, and 'b' has an even frequency of 2.
The maximum difference is 5 - 2 = 3.

Example 2:
Input: s = "abcabcab"
Output: 1
Explanation:
The character 'a' has an odd frequency of 3, and 'c' has an even frequency of 2.
The maximum difference is 3 - 2 = 1.
 */

import java.util.*;

public class Question_3442 {
    public static void main(String[] args) {

//        String s = "aaaaabbc";
        String s = "abcabcab";

        System.out.println(maxDifference(s));
        System.out.println(maxDifference2(s));
        System.out.println(maxDifference3(s));
    }

    public static int maxDifference(String s) {

        Set<Character> set = new HashSet<>();

        int min = Integer.MAX_VALUE;
        int max = Integer.MIN_VALUE;

        for (int i = 0; i < s.length(); i++) {
            set.add(s.charAt(i));
        }

//        System.out.println(set);

        for (char ch : set) {
            int temp = 0;
            for (int i = 0; i < s.length(); i++) {
                char c = s.charAt(i);
                if (ch == c) {
                    temp++;
                }
            }

            if (temp % 2 != 0) {
                max = Math.max(max, temp);
            } else {
                min = Math.min(min, temp);
            }
        }

        return max - min;
    }

    public static int maxDifference2(String s) {

        int max = Integer.MIN_VALUE;
        int min = Integer.MAX_VALUE;

        Map<Character, Integer> map = new HashMap<>();

        for (char c : s.toCharArray()) {
            map.put(c, map.getOrDefault(c, 0) + 1);
        }

        for (int count : map.values()) {
            if (count % 2 != 0) {
                max = Math.max(max, count);
            } else {
                min = Math.min(min, count);
            }
        }

        return max - min;
    }

    public static int maxDifference3(String s) {

        int[] freq = new int[26];
        for (char c : s.toCharArray()) {
            freq[c - 'a']++;
        }

        int maxOdd = Integer.MIN_VALUE;
        int minEven = Integer.MAX_VALUE;

        for (int f : freq) {
            if (f == 0) continue;
            if ((f & 1) == 1) { // odd
                maxOdd = Math.max(maxOdd, f);
            } else { // even
                minEven = Math.min(minEven, f);
            }
        }

        return (maxOdd == Integer.MIN_VALUE || minEven == Integer.MAX_VALUE) ? 0 : maxOdd - minEven;
    }

}
