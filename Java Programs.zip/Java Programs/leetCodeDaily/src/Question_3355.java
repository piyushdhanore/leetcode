/*
3355. Zero Array Transformation I

You are given an integer array nums of length n and a 2D array queries,
where queries[i] = [li, ri].
For each queries[i]:
Select a subset of indices within the range [li, ri] in nums.
Decrement the values at the selected indices by 1.
A Zero Array is an array where all elements are equal to 0.

Return true if it is possible to transform nums into a Zero Array after processing
all the queries sequentially, otherwise return false.

Example 1:
Input: nums = [1,0,1], queries = [[0,2]]
Output: true
Explanation:
For i = 0:
Select the subset of indices as [0, 2] and decrement the values at these indices by 1.
The array will become [0, 0, 0], which is a Zero Array.

Example 2:
Input: nums = [4,3,2,1], queries = [[1,3],[0,2]]
Output: false
Explanation:
For i = 0:
Select the subset of indices as [1, 2, 3] and decrement the values at these indices by 1.
The array will become [4, 2, 1, 0].
For i = 1:
Select the subset of indices as [0, 1, 2] and decrement the values at these indices by 1.
The array will become [3, 1, 0, 0], which is not a Zero Array.
 */

import java.util.Arrays;

public class Question_3355 {
    public static void main(String[] args) {

//        int [] nums = {4,3,2,1};
//        int [][] queries = {{1,3},{0,2}};

        int [] nums = {1,0,1};
        int [][] queries = {{0,2}};

//        System.out.println(isZeroArray(nums,queries));
//        System.out.println(isZeroArray(nums,queries));
        System.out.println(isZeroArray3(nums,queries));
    }

    public static boolean isZeroArray(int[] nums, int[][] queries) {

        int [] temp = Arrays.copyOfRange(nums,1,3);

//        for (int i = 0; i < Arrays.copyOfRange(nums,1,3).length; i++) {
//            System.out.println(nums[i]);
//            nums[i]-=1;
//        }

        for (int i = 0; i < temp.length; i++) {
            System.out.println(temp[i]);
            temp[i]-=1;
        }

        System.out.println(Arrays.toString(temp));


        return false;
    }

    public static boolean isZeroArray2(int[] nums, int[][] queries) {

//        int [] temp = Arrays.copyOfRange(nums,1,3);

        for (int i = 0; i < queries.length; i++) {
            int a=0,b=0;
            for (int j = 0; j < queries[i].length-1; j++) {
                a = queries[i][j];
                b = queries[i][j+1];
            }

            for (int j = a; j <=b; j++) {
                if (nums[j]==0) continue;
                nums[j]-=1;
            }
        }

        System.out.println(Arrays.toString(nums));

        for (int i = 0; i < nums.length; i++) {
            if (nums[i]!=0){
                return false;
            }
        }

        return true;
    }

    public static boolean isZeroArray3(int[] nums, int[][] queries) {

        for(int [] query: queries){
            int left = query[0];
            int right = query[1];

            for (int i = left; i <=right; i++) {
                if (nums[i]>0){
                    nums[i]--;
                }
            }

        }

        System.out.println(Arrays.toString(nums));

        for(int num: nums){
            if (num!=0) return false;
        }

        return true;
    }

    public static boolean isZeroArray4(int[] nums, int[][] queries) {
        int n = nums.length;
        int[] diff = new int[n + 1]; // difference array

        // Apply range updates
        for (int[] query : queries) {
            int left = query[0];
            int right = query[1];
            diff[left] -= 1;
            if (right + 1 < n) {
                diff[right + 1] += 1;
            }
        }

        // Apply the difference array to nums
        int delta = 0;
        for (int i = 0; i < n; i++) {
            delta += diff[i];
            nums[i] += delta;
            if (nums[i] != 0) return false;
        }

        return true;
    }


}
