/*
3403. Find the Lexicographically Largest String From the Box I

You are given a string word, and an integer numFriends.

Alice is organizing a game for her numFriends friends. There are multiple rounds in the game, where in each round:

word is split into numFriends non-empty strings, such that no previous round has had the exact same split.
All the split words are put into a box.
Find the lexicographically largest string from the box after all the rounds are finished.

Example 1:
Input: word = "dbca", numFriends = 2
Output: "dbc"
Explanation:
All possible splits are:
"d" and "bca".
"db" and "ca".
"dbc" and "a".

Example 2:
Input: word = "gggg", numFriends = 4
Output: "g"
Explanation:
The only possible split is: "g", "g", "g", and "g".
 */

import java.util.ArrayList;
import java.util.List;

public class Question_3403 {

    static String maxString = "";

    public static String getLargestString(String word, int numFriends) {
        backtrack(word, 0, numFriends, new ArrayList<>());
        return maxString;
    }

    private static void backtrack(String word, int index, int partsLeft, List<String> current) {

        if (partsLeft == 0 && index == word.length()) {
            for (String s : current) {
                if (s.compareTo(maxString) > 0) {
                    maxString = s;
                }
            }
            return;
        }

        if (partsLeft == 0 || index == word.length()) return;

        for (int i = index + 1; i <= word.length(); i++) {
            current.add(word.substring(index, i));
            backtrack(word, i, partsLeft - 1, current);
            current.remove(current.size() - 1);
        }
    }

    public static void main(String[] args) {
        System.out.println(getLargestString("dbca", 2)); // Output: "dbc"
        System.out.println(getLargestString("gggg", 4)); // Output: "g"
    }

}
